

<?php $__env->startSection('content'); ?>
    <!-- You are: (shop domain name) -->
    <p>You are: <?php echo e($shopDomain ?? Auth::user()->name); ?></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
    
    <script>
        
        $(document).ready(function(){
            
            //var order_id = $().attr('data-id');
            
            $.ajax({
                url: 'fetch/awb',
                type: "POST",
                data: {
                    order_id: '1011',
                },
                dataType: 'json',
                success: function (data) {
                    
                    alert(data.shipped_date);
                }
            });
            
            
        });
        
    </script>
    
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/chainpul/public_html/gravol-orders.chainpulse.tech/resources/views/welcome.blade.php ENDPATH**/ ?>