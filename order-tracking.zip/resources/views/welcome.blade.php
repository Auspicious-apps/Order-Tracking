@extends('shopify-app::layouts.default')

@section('content')
    <!-- You are: (shop domain name) -->
    <p>You are: {{ $shopDomain ?? Auth::user()->name }}</p>
@endsection

@section('scripts')
    @parent
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
    
    <script>
        
        $(document).ready(function(){
            
            //var order_id = $().attr('data-id');
            
            $.ajax({
                url: 'fetch/awb',
                type: "POST",
                data: {
                    order_id: '1011',
                },
                dataType: 'json',
                success: function (data) {
                    
                    alert(data.shipped_date);
                }
            });
            
            
        });
        
    </script>
    
    
    
@endsection