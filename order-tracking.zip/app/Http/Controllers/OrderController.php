<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");

class OrderController extends Controller
{
    
    public function get_tracking_number(Request $request)
    {
        
        $order_id = $request->input('order_id');
        
        
        $headers = array(
                "Content-Type: application/json",
                "Accept: application/json",
        );
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.diggipacks.com//orders/API/GetDetails',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{
                "customerId": "168052266339",
                "format": "json",
                "secret_key": "75e775-2e3f3a-881328-525782-46d7ae",
                "param": {
                    "booking_id":"'.$order_id.'"
                }
            }',
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers)
        ));
    
        $response = curl_exec($curl);
        curl_close($curl);
        
        $obj = json_decode($response);
                        
        $response_result = $obj->result;
        
        $awb = $response_result->slip_no;
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.diggipacks.com/API/trackShipmentfm',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{"awb": "'.$awb.'"}',
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers)
        ));
    
        $response1 = curl_exec($curl);
        curl_close($curl);
        
        $response_obj = json_decode($response1);
        
        $shipping_details = $response_obj ->shipment_data;
        
        $status = $shipping_details->status;
        
        $travel_history = $response_obj ->travel_history;
        
        $history_size = sizeof($travel_history);
        
        $comment = $travel_history[$history_size - 1]->comment;
           
        $carrier = substr($comment, strpos($comment, ")") + 2);   
        
        $shipped_date = $travel_history[$history_size - 1]->entry_date;
        
        $formatted_date = \Carbon\Carbon::parse($shipped_date)->format('d F, Y');
        
        $tracking_history = [];
        
        for($i=0;$i<$history_size;$i++) 
        {
            
            $track_status = $travel_history[$i]->new_status;
            
            $track_data = [];
            
            if($track_status == 'Order Created' || $track_status == 'Packed' || $track_status == 'In Transit' || $track_status == 'Out For Delivery' || $track_status == 'Delivered')
            {
                $t_date =  $travel_history[$i]->entry_date;
                $f_date = \Carbon\Carbon::parse($t_date)->format('d F, Y h:i A');
                
                $track_data['status'] = $track_status;
                $track_data['date'] = $f_date;
                
                $tracking_history[] = $track_data;
            }
            
        }
        
        return response()->json([ 'success' => true,"order_id"=>$order_id, "status" => $status, "shipped_date" => $formatted_date, "carrier" => $carrier, "travel_history" => $tracking_history]);
      
    }
    
}
